data:extend(
{

  {
    type = "item-subgroup",
    name = "advanced-equipment-equipment-energyshield",
    group = "combat",
    order = "n"
  },
  {
    type = "item-subgroup",
    name = "advanced-equipment-equipment-laser",
    group = "combat",
    order = "j"
  },
  {
    type = "item-subgroup",
    name = "advanced-equipment-equipment-exo",
    group = "combat",
    order = "k"
  },
  {
    type = "item-subgroup",
    name = "advanced-equipment-equipment-battery",
    group = "combat",
    order = "m"
  },
  {
    type = "item-subgroup",
    name = "advanced-equipment-equipment-reactor",
    group = "combat",
    order = "l"
  }
  
  
}
)
